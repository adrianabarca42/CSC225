### CSC 225, Assignment 2

Required files:
  * `rotate.bin`
  * `reverse.bin`

Optional files:
  * _none_
